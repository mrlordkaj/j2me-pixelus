/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;
import util.IOHelper;
import util.ImageHelper;

/**
 *
 * @author Thinh
 */
public class Loader extends Thread {
    private GamePage parent;
    
    public Loader(GamePage _parent) {
        parent = _parent;
    }
    
    public void run() {
        String parentClass = parent.getClass().getName();
        if(parentClass.equals(IslandMap.class.getName())) {
            loadIslandMapResource((IslandMap) parent);
        } else if(parentClass.equals(Temple.class.getName())) {
            loadTempleResource((Temple) parent);
        } else if(parentClass.equals(Play.class.getName())) {
            loadPlayResource((Play) parent);
        }
        parent.isLoading = false;
    }
    
    private void loadIslandMapResource(IslandMap map) {
        map.islandImage = Image.createImage(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
        Graphics g = map.islandImage.getGraphics();
        g.drawImage(ImageHelper.loadImage("/images/islandmap.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
        ImageHelper.medalSprite.setFrame(0);
        for(int i = 0; i < map.totalOpenedTemple; i++) {
            if(map.getTempleCompleted(i)) {
                //vẽ đền phát sáng
                g.drawImage(ImageHelper.loadImage("/images/map" + Story.characterName[i].toLowerCase() + "b.png"), IslandMap.templeRectangle[i][0], IslandMap.templeRectangle[i][1], Graphics.LEFT | Graphics.TOP);
                //vẽ huy chương cho đền hoàn hảo
                if(map.templeIsPerfect(i)) {
                    ImageHelper.medalSprite.setPosition(IslandMap.templeRectangle[i][0] + IslandMap.templeRectangle[i][2] / 2, IslandMap.templeRectangle[i][1] + IslandMap.templeRectangle[i][3] - 12);
                    ImageHelper.medalSprite.paint(g);
                }
            } else if(i != 0) {
                //vẽ đền bình thường
                g.drawImage(ImageHelper.loadImage("/images/map" + Story.characterName[i].toLowerCase() + "a.png"), IslandMap.templeRectangle[i][0], IslandMap.templeRectangle[i][1], Graphics.LEFT | Graphics.TOP);
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {}
        }
        
        map.lightingImage = ImageHelper.loadImage("/images/lighting.png");
        map.templeArrowImage = ImageHelper.loadImage("/images/templearrow.png");
        map.starSprite = new Sprite(ImageHelper.loadImage("/images/star.png"), 100, 16);
        map.starSprite.setPosition(20, 168);
        if(map.newTemple == 0) {
            map.story = Story.getStory(Story.STORY_CYLOP_CYLOP, (IslandMap)parent);
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {}
    }
    
    private void loadTempleResource(Temple temple) {
        Image lockImage = ImageHelper.loadImage("/images/lockpuzzleoverlay.png");
        Image pixelMask = ImageHelper.createPixelMask(3);
        
        //vẽ danh sách puzzle
        int templeId = temple.getTempleId();
        int numPuzzle = Puzzle.PUZZLE_FIRSTID[templeId + 1] - Puzzle.PUZZLE_FIRSTID[templeId];
        int width = 53 * 3 - 4;
        int height = temple.getPuzzleViewHeight();
        temple.puzzleViewImage = Image.createImage(width, height);
        Graphics g = temple.puzzleViewImage.getGraphics();
        if(temple.getTempleId() == Temple.TEMPLE_CYLOP) {
            //nếu là tutorial
            g.setColor(0x585866);
            g.fillRect(0, 0, width, height);
            for(int i = 1; i <= numPuzzle; i++) {
                int row = (i - 1) / 3;
                int col = (i - 1) % 3;
                if(i <= temple.getSolvedPuzzle()) {
                    drawPuzzleImage(i, col * 53, row * 53, 3, g, pixelMask, Puzzle.MEDAL_NONE);
                } else {
                    drawPuzzleCover(i, col * 53, row * 53, 3, g, pixelMask, Puzzle.MEDAL_NONE);
                }
                if(i > temple.getSolvedPuzzle() + 1) {
                    g.drawImage(lockImage, col * 53, row * 53, Graphics.LEFT | Graphics.TOP);
                }
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {}
            }
        } else {
            //nếu là các đền bình thường
            g.setColor(0xdda513);
            g.fillRect(0, 0, width, height);
            for(int i = 0; i < numPuzzle; i++) {
                int row = i / 3;
                int col = i % 3;
                if(temple.bestAmountTurn(i) > 0) {
                    drawPuzzleImage(i + Puzzle.PUZZLE_FIRSTID[templeId], col * 53, row * 53, 3, g, pixelMask, temple.medal(i));
                } else {
                    drawPuzzleCover(i + Puzzle.PUZZLE_FIRSTID[templeId], col * 53, row * 53, 3, g, pixelMask, temple.medal(i));
                }
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {}
            }
            if(!temple.lastPuzzleIsUnlocked()) {
                g.drawImage(lockImage, width - 1, height - 1, Graphics.RIGHT | Graphics.BOTTOM);
            }
        }
        //các resource còn lại
        temple.backgroundImage = ImageHelper.loadImage("/images/temple" + Story.characterName[temple.getTempleId()].toLowerCase() + ".png");
        temple.buttonImage = ImageHelper.loadImage("/images/buttongold.png");
        temple.scrollerImage = ImageHelper.loadImage("/images/scroller.png");
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {}
        
        temple.schedule = 40;
    }
    
    private void loadPlayResource(Play play) {
        play.tileSprite = new Sprite(ImageHelper.loadImage("/images/tile.png"), 12, 12);
        play.viewpotImage = Image.createImage(252, 240);
        play.viewpotGraphic = play.viewpotImage.getGraphics();
        play.viewpotGraphic.drawImage(ImageHelper.loadImage("/images/playbackground.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
        int puzzleId = play.getPuzzleId();
        Puzzle myPuzzle = Puzzle.getPuzzle(puzzleId);
        play.puzzleTitle = myPuzzle.getTitle();
        String data = myPuzzle.getData();
        String name = myPuzzle.getName();
        String title = myPuzzle.getTitle();
        myPuzzle = null;
        int row, col;
        byte value, tileRemain = 0, totalTile = 0;
        for(short i = 0; i < 16*16; i++) {
            row = i / 16;
            col = i % 16;
            value = (byte)data.charAt(i);
            play.tileSprite.setFrame(value);
            play.tileSprite.setPosition(col * 12 + 36, row * 12 + 24);
            play.tileSprite.paint(play.viewpotGraphic);
            play.cell[row][col] = play.defaultData[row][col] = value;
            switch(value) {
                case Play.TILE_WANT:
                case Play.TILE_STICKY:
                    tileRemain++;
                    totalTile++;
                    break;
                    
                case Play.TILE_BLUE:
                    totalTile++;
                    break;
                    
                case Play.TILE_RED:
                    tileRemain--;
                    break;
            }
        }
        data = null;
        //if(play.getTempleId() != Temple.TEMPLE_CYLOP) play.worldRecord = IOHelper.getFileSize("/data/hints/" + name + ".dat");
        if(play.getTempleId() != Temple.TEMPLE_CYLOP) play.hintData = IOHelper.read("/data/hints/" + name + ".dat");
        
        Image resourceImage = ImageHelper.loadImage("/data/images/" + name + ".gif");
        resourceImage.getRGB(play.rgb, 0, 16, 0, 0, 16, 16);
        
        int stackHeight = 12 * totalTile;
        play.stackImage = Image.createImage(12, stackHeight);
        Graphics g = play.stackImage.getGraphics();
        play.tileSprite.setFrame(Play.TILE_BLUE);
        for(int i = stackHeight - 12; i >= 0; i -= 12) {
            play.tileSprite.setPosition(0, i);
            play.tileSprite.paint(g);
        }
        play.tileStackY = 240 - 12 * tileRemain;
        
        int[] rgb = new int[12*12];
        for (int i = 0; i < rgb.length; ++i) rgb[i] = 0x44ffffff;
        play.possibleMask = Image.createRGBImage(rgb, 12, 12, true);
        for (int i = 0; i < rgb.length; ++i) rgb[i] = 0x22ff0000;
        play.imposibleMask = Image.createRGBImage(rgb, 12, 12, true);
        rgb = null;
        
        play.puzzleCompleteImage = Image.createImage(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
        g = play.puzzleCompleteImage.getGraphics();
        g.drawImage(ImageHelper.loadImage("/images/puzzlecompleted.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
        drawPuzzleImage(puzzleId, 128, 48, 4, g, ImageHelper.createPixelMask(4), 3);
        g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        g.setColor(0x000000);
        g.drawString(title, Main.SCREEN_WIDTH / 2 + 1, 130 + 1, Graphics.HCENTER | Graphics.BASELINE);
        g.setColor(0xffd800);
        g.drawString(title, Main.SCREEN_WIDTH / 2, 130, Graphics.HCENTER | Graphics.BASELINE);
        
        play.sidebarImage = Image.createImage(68, 240);
        g = play.sidebarImage.getGraphics();
        if(play.getTempleId() == Temple.TEMPLE_CYLOP) {
            g.drawImage(ImageHelper.loadImage("/images/tutorialsidebar.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
            String[] description = Tutorial.getDescription(play.getPuzzleId());
            for(int i = 0; i < description.length; i++) {
                g.drawString(description[i], 34, 14*i + 18, Graphics.HCENTER | Graphics.BASELINE);
            }
        } else {
            g.drawImage(ImageHelper.loadImage("/images/sidebarbackground.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
            g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
            g.setColor(0x00ff00);
            g.drawString(Integer.toString(play.hintData.length()), 32, 94, Graphics.HCENTER | Graphics.BASELINE);
        }
        
        play.characterSprite = new Sprite(ImageHelper.loadImage("/images/tilemaster.png"), 20, 26);
        play.characterSprite.setPosition(20, -2);
        
        play.aimImage = new Image[] {
            ImageHelper.loadImage("/images/aimup.png"),
            ImageHelper.loadImage("/images/aimright.png"),
            ImageHelper.loadImage("/images/aimdown.png"),
            ImageHelper.loadImage("/images/aimleft.png")
        };
        play.navImage = ImageHelper.loadImage("/images/navigator.png");
        play.shruggingSprite = new Sprite(ImageHelper.loadImage("/images/shrugging.png"), 20, 26);
        play.celebratingSprite = new Sprite(ImageHelper.loadImage("/images/celebrating.png"), 20, 35);
        play.cellMask = ImageHelper.loadImage("/images/cellmask.png");
        play.curtainImage = ImageHelper.loadImage("/images/curtain.png");
        play.calcPosible();
        play.updateCharacterSprite();
        
        if(play.getTempleId() == Temple.TEMPLE_CYLOP) {
            play.prepareTutorialStep();
        }
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {}
    }
    
    public static void drawPuzzleCover(int puzzleId, int x, int y, int size, Graphics g, Image pixelMask, int medal) {
        Puzzle puzzle = Puzzle.getPuzzle(puzzleId);
        String data = puzzle.getData();
        for(short i = 0; i < 16*16; i++) {
            int row = i / 16;
            int col = i % 16;
            switch(data.charAt(i)) {
                case Play.TILE_NONE: //0
                    g.setColor(0xeabc6e);
                    break;
                    
                case Play.TILE_WANT: //?
                    g.setColor(0xffe0b1);
                    break;
                    
                case Play.TILE_STICKY: //S
                    g.setColor(0x69db76);
                    break;
                    
                case Play.TILE_BLUE: //+
                    g.setColor(0x5df0e8);
                    break;
                    
                case Play.TILE_RED: //-
                    g.setColor(0xf95d5d);
                    break;
                    
                case Play.TILE_DARKBLUE: //X
                    g.setColor(0x228aa2);
                    break;
                    
                default:
                    g.setColor(0x000000);
                    break;
            }
            g.fillRect(col * size + x, row * size + y, size, size);
        }
        data = null;
        g.drawImage(pixelMask, x, y, Graphics.LEFT | Graphics.TOP);
        if(medal < Puzzle.MEDAL_NONE) {
            ImageHelper.medalSprite.setFrame(medal);
            ImageHelper.medalSprite.setPosition(x, y + 24);
            ImageHelper.medalSprite.paint(g);
        }
    }
    
    public static void drawPuzzleImage(int puzzleId, int x, int y, int size, Graphics g, Image pixelMask, int medal) {
        String name = Puzzle.getPuzzle(puzzleId).getName();
        Image resourceImage = ImageHelper.loadImage("/data/images/" + name + ".gif");
        
        int[] rgb = new int[16*16];
        resourceImage.getRGB(rgb, 0, 16, 0, 0, 16, 16);
        for(int i = 0; i < rgb.length; ++i) {
            int row = i / 16;
            int col = i % 16;
            g.setColor(rgb[i]);
            g.fillRect(col * size + x, row * size + y, size, size);
        }
        g.drawImage(pixelMask, x, y, Graphics.LEFT | Graphics.TOP);
        if(medal < Puzzle.MEDAL_NONE) {
            ImageHelper.medalSprite.setFrame(medal);
            ImageHelper.medalSprite.setPosition(x, y + 24);
            ImageHelper.medalSprite.paint(g);
        }
    }
    
    public static Image confirmDialog(String[] message){
        final int WIDTH = 252;
        final int HEIGHT = 182;
        Image dialog = Image.createImage(WIDTH, HEIGHT);
        Graphics g = dialog.getGraphics();
        
        //vẽ bảng thông báo
        g.drawImage(ImageHelper.loadImage("/images/dialog.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
        
        //viết nội dung thông báo
        g.setColor(0, 0, 0);
        for(int i = 0; i < message.length; i++) {
            g.drawString(message[i], WIDTH / 2, 57 + i * 20, Graphics.HCENTER | Graphics.BASELINE);
        }
        
        //nút okie
        g.drawImage(ImageHelper.loadImage("/images/buttongold.png"), 84, 140, Graphics.HCENTER | Graphics.VCENTER);
        g.drawString("Okie", 84, 146, Graphics.HCENTER | Graphics.BASELINE);
        //nút cancel
        g.drawImage(ImageHelper.loadImage("/images/buttonsilver.png"), WIDTH - 84, 140, Graphics.HCENTER | Graphics.VCENTER);
        g.drawString("Cancel", WIDTH - 84, 146, Graphics.HCENTER | Graphics.BASELINE);
        
        //xóa nền rồi trả về hình ảnh
        int[] rgb = new int[WIDTH * HEIGHT];
        dialog.getRGB(rgb, 0, WIDTH, 0, 0, WIDTH, HEIGHT);
        for (int i = 0; i < rgb.length; ++i) {
            if (rgb[i] == 0xffff00ff) {
                rgb[i] &= 0x00ffffff;
            }
        }
        return Image.createRGBImage(rgb, WIDTH, HEIGHT, true);
    }
    
    public static Image messageDialog(String[] message){
        final int WIDTH = 252;
        final int HEIGHT = 182;
        Image dialog = Image.createImage(WIDTH, HEIGHT);
        Graphics g = dialog.getGraphics();
        
        //vẽ bảng thông báo
        g.drawImage(ImageHelper.loadImage("/images/dialog.png"), 0, 0, Graphics.LEFT | Graphics.TOP);
        
        //viết nội dung thông báo
        g.setColor(0, 0, 0);
        for (int i = 0; i < message.length; i++) {
            g.drawString(message[i], WIDTH / 2, 57 + i * 20, Graphics.HCENTER | Graphics.BASELINE);
        }
        
        //nút okie
        g.drawImage(ImageHelper.loadImage("/images/buttongold.png"), WIDTH / 2, 140, Graphics.HCENTER | Graphics.VCENTER);
        g.drawString("Okie", WIDTH / 2, 146, Graphics.HCENTER | Graphics.BASELINE);
        
        //xóa nền rồi trả về hình ảnh
        int[] rgb = new int[WIDTH * HEIGHT];
        dialog.getRGB(rgb, 0, WIDTH, 0, 0, WIDTH, HEIGHT);
        for (int i = 0; i < rgb.length; ++i) {
            if (rgb[i] == 0xffff00ff) {
                rgb[i] &= 0x00ffffff;
            }
        }
        return Image.createRGBImage(rgb, WIDTH, HEIGHT, true);
    }
}
