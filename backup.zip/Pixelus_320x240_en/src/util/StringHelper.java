/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Thinh
 */
public class StringHelper {
    public static String[] split(String sb, String splitter) {
        String[] strs = new String[sb.length()];
        int splitterLength = splitter.length();
        int initialIndex = 0;
        int indexOfSplitter = sb.indexOf(splitter, initialIndex);
        int count = 0;
        if (-1 == indexOfSplitter) {
            return new String[]{sb.toString()};
        }
        while (-1 != indexOfSplitter) {
            char[] chars = new char[indexOfSplitter - initialIndex];
            sb.getChars(initialIndex, indexOfSplitter, chars, 0);
            initialIndex = indexOfSplitter + splitterLength;
            indexOfSplitter = sb.indexOf(splitter, indexOfSplitter + 1);
            strs[count] = new String(chars);
            count++;
        }
        // get the remaining chars.
        if (initialIndex + splitterLength <= sb.length()) {
            char[] chars = new char[sb.length() - initialIndex];
            sb.getChars(initialIndex, sb.length(), chars, 0);
            strs[count] = new String(chars);
            count++;
        }
        String[] result = new String[count];
        System.arraycopy(strs, 0, result, 0, count);
        return result;
    }
}
