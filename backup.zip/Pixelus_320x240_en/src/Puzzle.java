/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import util.IOHelper;

/**
 *
 * @author Thinh
 */
public class Puzzle {
    public static final int[] PUZZLE_FIRSTID = new int[] {1, 10, 22, 37, 55, 76, 100, 127, 154, 181, 211};
    public static final int MEDAL_NONE = 3;
    public static final int MEDAL_BRONZE = 2;
    public static final int MEDAL_SILVER = 1;
    public static final int MEDAL_GOLDEN = 0;
    
    private String name;
    private String title;
    private String data;
    
    public static Puzzle getPuzzle(int id) {
        String[] puzzleData = IOHelper.readPuzzleData(id);
        return new Puzzle(puzzleData[0], puzzleData[1], puzzleData[2]);
    }
    
    private Puzzle(String _name, String _title, String _data) {
        name = _name;
        title = _title;
        data = _data;
    }
    
    public String getName() { return name; }
    public String getTitle() { return title; }
    public String getData() { return data; }
}
