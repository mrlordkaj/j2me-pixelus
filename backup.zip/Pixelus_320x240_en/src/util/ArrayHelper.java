/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Thinh
 */
public class ArrayHelper {
    public static boolean inArray(int value, int[] array) {
        for(int i = 0; i < array.length; i++) {
            if(value == array[i]) {
                return true;
            }
        }
        return false;
    }
}
