/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Graphics;

/**
 *
 * @author Thinh
 */
public abstract class StoryPage {
    public abstract void update();
    public abstract void paint(Graphics g);
    public abstract void pointerPressed(int x, int y);
    public abstract void dispose();
}
