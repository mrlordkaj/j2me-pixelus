/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thinh
 */
public interface StoryPlayer {
    public void closeStory();
    public String getPlayerName();
}
