/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import util.ImageHelper;

/**
 *
 * @author Thinh
 */
public class Help extends GamePage {
    private boolean touching = false;
    private Image backgroundImage, titleImage;
    private String[] helpContent = new String[] {
        "PIXELUS: MOBILE EDITION",
        "Version: 1.1",
        "Developed by Openitvn Forum",
        "Based on the same game of Nuclide.com",
        "",
        "==================",
        "OBJECTIVE",
        "The objective of Pixelus is to complete the",
        "mosaic puzzles in the shortest number of moves",
        "possible. The 'World Record' in the right side bar",
        "indicates the least number of moves required",
        "to complete the current puzzle.",
        "",
        "==================",
        "CONTROLS",
        "Place your cursor on the position where you want",
        "to place a tile. Tap on the ok button to place",
        "the tile. To remove a tile you have already placed,",
        "position the cursor on top of the tile you wish to",
        "remove, and tap on ok button. The tile can only",
        "be removed if it is not blocked by another tile.",
        "",
        "==================",
        "CREDITS",
        "Gameplay & Art: Nuclide.com",
        "Programming: Thịnh Phạm",
        "",
        "Special thanks for:",
        "Lee.DC",
        "matran999",
        "",
        "Pixelus is a trademark of Nuclide.com BVBA.",
        "Copyright © 2004 Nuclide. All rights reserved.",
        "",
        "Pixelus Mobile is a non-commercial product",
        "which is developed by members of Openitvn",
        "under limited license agreement of Nuclide.",
        "It's free, don't pay anything for!",
        "",
        "The Openitvn logo is a trademark of Openitvn.",
        "Copyright © 2013 Openitvn. All rights reserved.",
        "",
        "Website: http://openitvn.net",
        "Support: mrlordkaj@gmail.com"
    };
    private int marginTop = Main.SCREEN_HEIGHT + 20;
    
    private Main parent;
    
    public Help(Main _parent) {
        super();
        parent = _parent;
        
        prepareResource();
        
        schedule = 80;
        new Thread(this).start();
    }
    
    private void prepareResource() {
        backgroundImage = ImageHelper.loadImage("/images/storybackground.png");
        titleImage = ImageHelper.loadImage("/images/helptitle.png");
        isLoading = false;
    }
    
    protected void update() {
        if(isLoading) return;
        
        if(marginTop > 70 - helpContent.length*20) {
            if(touching) marginTop -= 4;
            else marginTop--;
        }
        else marginTop = Main.SCREEN_HEIGHT + 20;
    }
    
    public void paint(Graphics g) {
        if(isLoading) return;
        
        g.drawImage(backgroundImage, 0, 0, Graphics.LEFT | Graphics.TOP);
        g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        for(int i = 0; i < helpContent.length; i++) {
            g.drawString(helpContent[i], Main.SCREEN_WIDTH / 2, marginTop + i*20, Graphics.HCENTER | Graphics.BASELINE);
        }
        g.drawImage(titleImage, 0, 0, Graphics.LEFT | Graphics.TOP);
    }
    
    protected void pointerPressed(int x, int y) {
        if(x > 0 && x < 80 && y > 0 && y < 60) {
            parent.gotoMainMenu();
        } else {
            touching = true;
        }
    }
    
    protected void pointerReleased(int x, int y) {
        touching = false;
    }
    
    public void dispose() {
        isLoading = true;
        pageLooping = false;
        backgroundImage = null;
        titleImage = null;
        helpContent = null;
    }
}
